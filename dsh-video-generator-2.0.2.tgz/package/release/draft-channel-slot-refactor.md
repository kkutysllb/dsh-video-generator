# 【草案 · 未发布】通道层重构：用途槽（每槽单模型）+ 通用音乐适配器

> **状态：草案，禁止发版。** 版本号未定、未经需求方确认前不得执行任何发布链
> （commit 到 main / tag / npm publish / 镜像 / GitHub Release 均不得进行）。
> 本文件仅作为变更说明草稿随功能分支评审。

## 版本信息

- **版本**：未定（草稿；发版版本号由需求方确认）
- **日期**：2026-09-28
- **分支**：`feat/channel-slot-refactor`
- **设计依据**：`docs/superpowers/specs/2026-09-28-channel-slot-refactor-design.md`（需求方逐条确认：6 槽位 / 每槽单模型 / image 两槽可同模型 / 音乐通用适配器零 provider 绑定 / 模板预填 / MV 先曲后镜 / BGM 默认开）
- **实施计划**：`plans/2026-09-28-channel-slot-refactor-p0.md`（P0 范围）

## 新增

- **用途槽（Use-Slot）配置范式**：6 个槽位（`image.master` 主图 / `image.shot` 逐镜图 / `video` 视频 / `tts` 配音 / `music.bgm` 背景乐 / `music.song` MV 主曲），每槽**恰好绑定一个模型**——数据结构层无法表达第二候选，"多模型轮询/自动兜底"被类型排除。
- **槽位能力位声明**：video 槽勾 `imageToVideo`/`textToVideo`（未勾 t2v 且无参考图 → 明确失败，不找替代模型）；image 槽 `sizeParam`/`referenceImage`；tts 槽 `voice`/`instructions`；能力位缺省值显式落库。
- **通用音乐适配器（`generic-music`）**：声明式端点映射（endpoint.path / request.promptField / response.audioPath / mode；async 另需 statusPath+jobIdPath），代码零 provider 分支；同步直返与异步任务轮询两种形态；支持 base64 音频与签名 URL。
- **音乐映射模板**：4 个内置模板按**协议形态**命名（同步 URL / 同步 base64 / 异步轮询 / 异步+段落时间戳），纯数据预填、不含凭证与模型名；用户可另存/删除自己的模板。
- **槽位「测试」**：每个槽一次**真实最小调用**（图 512px / 视频 5s / TTS 一句 / 音乐 8s），结论写回 `verifiedAt/verifyNote`（成败都留痕）——落地原规格 §4.3③「按模型小额实跑验证」。
- **t2v 降级路径**：video 槽勾选 `textToVideo` 后，无参考图时自动文生视频并在 clips 事件记录 `mode:'t2v'`。
- **通道级验证留痕**：`channels.test` 写入 `verifiedAt`（连通/鉴权/枚举自检）。
- **vault v2 数据结构**：`{channels, slots, musicTemplates, budget, gateDefaults}`；`deleteChannel` 级联清除引用它的槽位绑定并返回 `clearedSlots`。
- **RPC 面**：新增 `slots.list/get/set/clear/test` 与 `musicTemplates.list/save/delete`。

## 变更

- **确认阈值真正生效**：估价未知一律确认；估价 ≤ 阈值（默认 ¥1，可改）放行；超阈值确认（旧版恒要求 confirm，阈值设置形同虚设）。
- **累计记账接线**：每次 submit 成功写 `SpendLedger`（`vgen_channels spend` 的全局 totals 不再恒 0）；记账失败不阻断生成；账本路径与 vault/runs 统一 `harnessHome` 口径（QiLin 一致）。
- **run 保留策略接线**：创建 run 时自动 `prune(50)`（旧版 prune 存在但无调用方）。
- **协议在绑定级显式声明**（`openai-images` / `openai-tts` / `dashscope-video` / `kling-video` / `openai-video` / `generic-music`），不再按模型名猜；`openai-video` 按 Sora 风格 /v1/videos 实现（真机待钉）；DashScope 提交补 `X-DashScope-Async: enable` 头（对齐附录 B.4）。
- **估价按通道**：不同槽可绑不同站点，价目表按各槽通道分别拉取。
- **设置页三区**：通道（测试不导入）/ 用途槽（六行绑定 + 测试 + 音乐模板）/ 预算与 gate；`testOk` 文案口径更新。
- **脚本直连**：`scripts/*` 经 `VGEN_IMAGE_MODEL`/`VGEN_VIDEO_MODEL`/`VGEN_TTS_MODEL` 合成槽位绑定（修复 v1.0.4 起 demo/续跑脚本因模型选择改造失效的问题）；`npm run demo:mock` 内置 mock 槽位恢复零 key 全链路。

## 修复

- **确认阈值不生效**（生产 confirmer 不读 `confirmThresholdCny`）→ `confirmSpend` 语义接线（本仓审计 A4）。
- **累计消耗恒 0**（`SpendLedger.record` 无生产调用方）→ 生成/评审重拍全部落账（审计 A3）。
- **demo/运维脚本失效**（注入通道缺 `models[]` → `model-unavailable`）→ env 槽位合成（审计 A1/A2）。
- **记账失败阻断生成**（EPERM → internal）→ `recordSafe`（不阻断，留错误日志）。
- `refreshStudio` 悬空引用、15 个 picker 时代死词典键 → 清理。

## 删除（破坏性）

- **模型池**：通道 `models[]`、`endpointProfile`、`channels.adoptModels`、`channels.setDefault`（默认通道概念取消——每槽各自选通道）。
- **枚举导入面**：设置页模型勾选面板（PickerPanel ~150 行）、`assemblePickerRowsPublic`、`inferKindByName`、`src/picker/assemble.ts`、`src/model-catalog.ts`（内置目录"按名推断形态"随之退役，迁移函数内保留一次性启发式）。
- `src/registry.ts`（`providerForModel`）→ `src/providers/protocols.ts`（`providerForSlot`，协议驱动）。

## 兼容性与升级说明

- **配置迁移**：首次加载旧 `vault.json` 自动迁移（规则见 README「通道配置」节），原文件备份 `vault.json.v1.bak-<时间戳>`；回滚 = 备份覆盖 + 装回旧版。迁移只认默认通道的 `models[]`（v1 运行时语义本就只用默认通道），其余通道模型清单在备份中。
- **行为**：未绑定槽位消费返回 `model-unavailable`（含槽位名与设置指引），确认与花费为零；`image.shot` 未绑定回落 `image.master`（唯一回落）。
- **RPC**：`channels.adoptModels` / `channels.setDefault` 调用返回 `unknown-method`；`channels.create/update` 不再接受 `models`。
- **宿主/数据**：宿主版本要求不变（0.1.5+）；runs/vault/spend 数据根不变。
- 升级方式：`dsh plugin --profile web update dsh-video-generator`（KCoder 桌面端带 `DSH_HOME=~/.kcoder`）。

## 验证

| 项 | 结果 |
|---|---|
| `npm run typecheck` | ✅ |
| `npm test` | ✅（全量回归见发版 checklist 执行记录） |
| `npm run demo:mock` | ✅ 零 key mock 全链路恢复（三段交接 → assets → video → final → 评审抽帧） |
| 迁移 | 单测钉死（典型 v1 / 默认通道缺失 / kling·t2v 启发式 / 备份字节一致 / 幂等） |
| 静态断言 | 适配器与模板数据无 provider 条件分支；bundle 旧 picker 符号 `doesNotMatch` |
| 真机 | 待办：最小 profile boot + 真实通道槽位测试各槽一次 + 迁移真机验证（发版前执行） |

## P1 —— 音乐段（同批草案，未发布）

### 新增

- **`music` 段**（STAGES 第八段，video 之后 final-cut 之前）：绑定 `music.bgm` 即自动生成 BGM（`music/bgm.mp3` + `music-done` 事件）；`vgen_generate` target 增 `'music'`；rerunStage 支持 `music`。
- **BGM 默认策略（D6）**：未绑定槽 → `music-skip` 事件跳过，不阻断成片；过段失败（target=final 路径）吞错误继续出片，显式 target=music 才上抛。
- **BGM 混音**：渲染端 `stream_loop` 循环补长 + `atrim` 裁切成片总长 + 首尾 0.5s `afade` + **`sidechaincompress` ducking**（人声总线作侧链压音乐，默认垫底音量 0.22）；产物页新增 BGM 音频播放器。
- **歌词资产**：`vgen_script` 可选 `lyrics` 字段（≤20000 字符），落盘 `runs/<id>/lyrics.json`（music.song/MV 消费，P2）。
- **工具取消信号转发（B1）**：`vgen_generate` 的 `execute` 透传 `exec.signal`，与宿主停用信号 `AbortSignal.any` 组合——工具超时/取消在段边界与并发泵检查点停下，不再后台空烧。

### 变更

- 诊断卡「TTS 能力」提示文案改为用途槽口径。

### 测试

- 279 → **292**（music 段 4 + BGM 混音 2 + lyrics 2 + artifacts/timeline/tools-generate/client 各 1）；`demo:mock` 零 key 全链路（含 music-skip 路径）EXIT=0。

## 发布链

（**全部冻结**，见顶部状态声明）
